<?php
    global $post;
    $product_price = get_post_meta($post->ID,'product_price',true);
    $product_price_sale = get_post_meta($post->ID,'product_price_sale',true);
    $product_stock = get_post_meta($post->ID,'product_stock',true);
?>
<table class="form-table">
<tr>
<th scope="row"><label for="blogname">Giá sản phẩm</label></th>
<td><input name="product_price" type="text" value="<?= $product_price ?>" class="regular-text"></td>
</tr>
<tr>
<th scope="row"><label for="blogname">Giá khuyến mại</label></th>
<td><input name="product_price_sale" type="text" value="<?= $product_price_sale ?>" class="regular-text"></td>
</tr>
<th scope="row"><label for="blogname">Giá khuyến mại</label></th>
<td><input name="product_stock" type="text" value="<?= $product_stock ?>" class="regular-text"></td>
</tr>
</table>