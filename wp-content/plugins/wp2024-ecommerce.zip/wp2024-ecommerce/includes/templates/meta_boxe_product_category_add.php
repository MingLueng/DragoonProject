
<div class="form-field">
    <label for = "image">Hình ảnh</label>
    <input name="image" id="image" type="text" value="" size="40">
</div>
