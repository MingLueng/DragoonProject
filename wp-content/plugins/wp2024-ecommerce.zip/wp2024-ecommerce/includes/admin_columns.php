<?php
//Hiển thị các cột posttype của sản phẩm 
add_filter('manage_product_posts_columns','wp2024_admin_columns_product_filter_columns');
function wp2024_admin_columns_product_filter_columns($columns){
    $columns['product_price'] = "Giá bán";
    $columns['product_price_sale'] = "Giá khuyến mại";
    $columns['product_stock'] = "Số lượng";
    return $columns;
}
//Hiển thị giá trị của các cột ra
add_action('manage_product_posts_custom_column','wp2024_admin_columns_product_render_columns',10,2);

function wp2024_admin_columns_product_render_columns($column_name,$post_id){

    switch($column_name){
        case 'product_price':
            $product_price = get_post_meta($post_id,'product_price',true);
            echo number_format($product_price);
            
            break;
        case 'product_price_sale':
            $product_price_sale = get_post_meta($post_id,'product_price_sale',true);
            echo number_format($product_price_sale);
            break;
        case 'product_stock':
            echo get_post_meta($post_id,'product_stock',true);
            break;
    }
}
//Hiên thị các cột của taxonomy product_category
add_filter('manage_edit_product_category_columns','wp2024_admin_columns_taxonomy_filter_columns');
function wp2024_admin_columns_taxonomy_filter_columns($columns){
    $columns['image'] =="Ảnh";
    return $columns;
}


//Hiển thị giá trị của các cột image

add_action('manage_product_category_custom_column','wp2024_admin_columns_product_category_render_columns',10,3);
function wp2024_admin_columns_product_category_render_columns($term_id,$columns,$out)
{
    if($columns == 'image')
    {
        $image = get_post_meta($term_id,'image',true);
        echo $image;
    }
}






